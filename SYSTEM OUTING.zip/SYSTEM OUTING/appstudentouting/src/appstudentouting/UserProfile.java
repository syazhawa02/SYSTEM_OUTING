/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appstudentouting;

/**
 *
 * @author ACER PC
 */
public class UserProfile {
     private static String studentName;
    private static String id;
    private static String phoneNumber;
    private static String studentGuardian;
    private static String studentPlace;
    private static String studentBlok;

    public static String getStudentName() {
        return studentName;
    }

    public static void setStudentName(String studentName) {
        UserProfile.studentName = studentName;
    }

    public static String getId() {
        return id;
    }

    public static void setId(String id) {
        UserProfile.id = id;
    }

    public static String getPhoneNumber() {
        return phoneNumber;
    }

    public static void setPhoneNumber(String phoneNumber) {
        UserProfile.phoneNumber = phoneNumber;
    }

    public static String getStudentGuardian() {
        return studentGuardian;
    }

    public static void setStudentGuardian(String studentGuardian) {
        UserProfile.studentGuardian = studentGuardian;
    }

    public static String getStudentPlace() {
        return studentPlace;
    }

    public static void setStudentPlace(String studentPlace) {
        UserProfile.studentPlace = studentPlace;
    }

    public static String getStudentBlok() {
        return studentBlok;
    }

    public static void setStudentBlok(String studentBlok) {
        UserProfile.studentBlok = studentBlok;
    }

    
}
